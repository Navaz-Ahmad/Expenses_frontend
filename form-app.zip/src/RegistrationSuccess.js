import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import logo from "./Assests/logo.PNG"; // Make sure path is correct

const RegistrationSuccess = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Retrieve data passed from the registration form
  const { uniqueId, fullName, region } = location.state || {};

  return (
    <div className="container py-5 text-center">
      <div className="card shadow-lg p-4 mx-auto" style={{ maxWidth: "600px" }}>
        <div className="card-body">
          <img
            src={logo}
            alt="SPICON Logo"
            style={{ width: "100px", marginBottom: "20px" }}
          />
          
          <h2 className="text-success fw-bold mb-3">Registration Successful!</h2>
          <p className="lead">
            Thank you <strong>{fullName}</strong> for registering for SPICON-2026 ({region}).
          </p>
          
          <hr />

          <div className="alert alert-info py-4">
            <h5 className="fw-bold">Your Unique Registration ID</h5>
            <h1 className="display-6 fw-bold text-primary my-2">{uniqueId || "PENDING"}</h1>
            <small className="text-muted">
              Please save this ID for future reference and check-in.
            </small>
          </div>

          <p className="mt-3">
            You will be added to the {region} WhatsApp group shortly.
          </p>

          <button 
            className="btn btn-primary px-4 mt-3" 
            onClick={() => navigate("/")}
          >
            Return to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default RegistrationSuccess;